#ifdef BITMAP_H
#define BITMAP_H

#include "./multimod.h"


// BBall Sprite
extern const uint16_t ballSprite[10][10];

extern const uint16_t netSprite[10][20];

extern const uint16_t michaelJordanSprite[50][10];

extern const uint16_t lebronJamesSprite[50][10];


#endif /* BITMAP_H */
